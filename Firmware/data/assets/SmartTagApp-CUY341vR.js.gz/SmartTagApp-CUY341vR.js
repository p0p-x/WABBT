import{u as t,j as e}from"./index-DUvdTrms.js";import{B as s}from"./common-BEBxH9eT.js";import"./Button-DHX7WF2Q.js";const o={id:"smarttag",opt:14,name:"Smart Tagger",class:"defensive",color:"primary",desc:`
  Detects smart tags
  such as AirTags and
  Tiles. It will attempt
  to connect and set
  off an audio alert
  on the device.`},p=()=>{const a=t();return e.jsx(s,{app:o,onBack:()=>a("/ble")})};export{p as SmartTagApp,p as default};
