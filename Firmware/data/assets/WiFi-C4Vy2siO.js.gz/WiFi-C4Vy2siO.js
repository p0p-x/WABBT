import{u as s,j as i}from"./index-DUvdTrms.js";import{M as r}from"./common-BEBxH9eT.js";import"./Button-DHX7WF2Q.js";const a=[{id:"deauth",name:"Deauth",class:"offensive",color:"error",desc:`
  Deauthenticates WIFI
  clients connected
  to networks. Can
  either target single
  stations or whole AP.
`},{id:"ddetect",name:"Deauth Detect",class:"defensive",color:"primary",desc:`
  Detects deauthentiction
  frames that are sent. Useful
  to figure out if your
  network is under attack
  or other maliciousness.
`},{id:"pmkid",opt:11,class:"offensive",color:"error",name:"PMKID",desc:`
  Collects PMKIDs to
  later be cracked
  on a more powerful
  device.
`}],l=()=>{const e=s(),t=o=>{e(`/wifi/${o.id}`)};return i.jsx(r,{apps:a,name:"WiFi",desc:"Tools for 2.4GHz WiFi Networks",onClick:t})};export{l as WiFi,l as default};
