import{u as p,r as d,j as t}from"./index-DJIs-emK.js";import{B as m,a as u}from"./common-Cbee4p2Y.js";import{T as x}from"./TextField-BqlaExlo.js";import{B as f}from"./Button-B0IXh9Bd.js";const r={id:"vhci",opt:9,name:"vHCI",class:"tool",color:"primary",desc:`
  Virtual HCI for the
  Bluetooth controller.
`},v=()=>{const i=p(),[o,l]=d.useState(""),a=(s,n)=>{var e;s.preventDefault(),console.log("Send",o),((e=window.socket)==null?void 0:e.readyState)===1&&(window.socket.send(JSON.stringify({opt:r.opt,action:"send",input:o})),n(c=>`${c}
Send: ${o}`))};return t.jsx(m,{app:r,onBack:()=>i("/ble"),children:t.jsx(u.Consumer,{children:({state:s,setOutput:n})=>t.jsx(t.Fragment,{children:s===1&&t.jsxs("form",{onSubmit:e=>a(e,n),children:[t.jsx(x,{value:o,onChange:e=>l(e.target.value),size:"small",placeholder:"HCI Cmd:"}),t.jsx(f,{sx:{ml:2},type:"submit",variant:"contained",color:"primary",onClick:e=>a(e,n),children:"Send"})]})})})})};export{v as VHCIApp,v as default};
