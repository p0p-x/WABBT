import{u as a,j as e}from"./index-DJIs-emK.js";import{B as s}from"./common-Cbee4p2Y.js";import"./Button-B0IXh9Bd.js";const p={id:"blespamd",opt:8,name:"Spam Detect",class:"defensive",color:"primary",desc:`
  Detects various BLE spam
  advertisement attacks that
  are known to cause disruptive
  actions and unwanted popups.
`},i=()=>{const t=a();return e.jsx(s,{app:p,onBack:()=>t("/ble")})};export{i as SpamDetectApp,i as default};
