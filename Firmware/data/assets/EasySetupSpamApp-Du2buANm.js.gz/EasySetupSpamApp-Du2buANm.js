import{u as a,j as e}from"./index-DJIs-emK.js";import{B as p}from"./common-Cbee4p2Y.js";import"./Button-B0IXh9Bd.js";const t={id:"esspam",opt:10,name:"EasySetup Spam",class:"offensive",color:"error",desc:`
  Sends Samsung EasySetup
  advertisements that can
  cause popups on some phones.
`},m=()=>{const s=a();return e.jsx(p,{app:t,onBack:()=>s("/ble")})};export{m as EasySetupSpamApp,m as default};
