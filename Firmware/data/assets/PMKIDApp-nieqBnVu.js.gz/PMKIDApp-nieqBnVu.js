import{u as g,r as y,j as e,T as i,G as c}from"./index-DJIs-emK.js";import{B as f,a as k,s as S,D as j}from"./common-Cbee4p2Y.js";import{B as r}from"./Button-B0IXh9Bd.js";const o={id:"pmkid",opt:11,name:"PMKID",desc:`
  Collects PMKIDs to
  later be cracked
  on a more powerful
  device. Either send
  deauth packets or try
  to connect to target AP
  with another device once
  running.
`},v=()=>{const d=g(),[p,l]=y.useState(!1),m=t=>{d("/wifi")},w=()=>{var t;((t=window.socket)==null?void 0:t.readyState)===1&&window.socket.send(JSON.stringify({opt:o.opt,action:"scan"}))},u=(t,n)=>{l(t),n(s=>s+=1)},h=t=>{var n;((n=window.socket)==null?void 0:n.readyState)===1&&(window.onOptSuccess=()=>setTimeout(()=>{window.location.reload(),window.onOptSuccess=!1},1e3),window.socket.send(JSON.stringify({opt:o.opt,action:"start",ap_id:t})))},x=()=>{var t;((t=window.socket)==null?void 0:t.readyState)===1&&window.socket.send(JSON.stringify({opt:o.opt,action:"deauth"}))};return e.jsx(f,{app:o,startFunc:w,onBack:m,children:e.jsx(k.Consumer,{children:({state:t,results:n,setState:s})=>e.jsxs(e.Fragment,{children:[t===1&&e.jsx(i,{variant:"body1",children:"Scanning APS..."}),t===2&&n&&e.jsxs(e.Fragment,{children:[e.jsxs(i,{variant:"body1",sx:{mb:2},children:["APS: ",n.length]}),e.jsx(c,{container:!0,spacing:2,children:n.sort(S).map(a=>e.jsx(c,{item:!0,xs:12,sm:6,md:4,lg:3,children:e.jsx(j,{dev:a,onClick:()=>u(a,s)})},a.id))})]}),t===3&&e.jsx(r,{type:"submit",variant:"contained",color:"primary",onClick:()=>h(p.id),children:"Start"}),t===4&&e.jsx(r,{type:"submit",variant:"contained",color:"primary",onClick:x,children:"Send Deauth"})]})})})};v.propTypes={};export{v as PMKIDApp,v as default};
