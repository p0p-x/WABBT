import{u as t,j as s}from"./index-DUvdTrms.js";import{B as a}from"./common-BEBxH9eT.js";import"./Button-DHX7WF2Q.js";const i={id:"bleskimd",opt:12,name:"Skimmer Detect",class:"defensive",color:"primary",desc:`
  Detects potential
  Gas Station Pump
  skimmers by looking
  for specific advertisements.
`},p=()=>{const e=t();return s.jsx(a,{app:i,onBack:()=>e("/ble")})};export{p as SkimmerDetectApp,p as default};
