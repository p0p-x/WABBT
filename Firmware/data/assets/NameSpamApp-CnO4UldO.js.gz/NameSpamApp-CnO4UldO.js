import{u as i,r as m,j as a}from"./index-DJIs-emK.js";import{B as d,a as l}from"./common-Cbee4p2Y.js";import{T as c}from"./TextField-BqlaExlo.js";import"./Button-B0IXh9Bd.js";const n={id:"nspam",opt:2,name:"Name Spam",desc:`
  Sends advertisments usings
  random MAC addresses. This
  will appear in your phones
  bluetooth when going to pair.`},f=()=>{const o=i(),[s,r]=m.useState(""),p=t=>{var e;t.preventDefault(),((e=window.socket)==null?void 0:e.readyState)===1&&window.socket.send(JSON.stringify({opt:n.opt,action:"start",name:s}))};return a.jsx(d,{app:n,startFunc:p,onBack:()=>o("/ble"),children:a.jsx(l.Consumer,{children:({state:t})=>a.jsx(a.Fragment,{children:t===0&&a.jsx("form",{onSubmit:e=>e.preventDefault(),children:a.jsx(c,{value:s,onChange:e=>r(e.target.value),size:"small",placeholder:"Hack tha plan8"})})})})})};export{f as NameSpamApp,f as default};
