import{u as t,j as s}from"./index-DJIs-emK.js";import{B as a}from"./common-Cbee4p2Y.js";import"./Button-B0IXh9Bd.js";const i={id:"bleskimd",opt:12,name:"Skimmer Detect",class:"defensive",color:"primary",desc:`
  Detects potential
  Gas Station Pump
  skimmers by looking
  for specific advertisements.
`},p=()=>{const e=t();return s.jsx(a,{app:i,onBack:()=>e("/ble")})};export{p as SkimmerDetectApp,p as default};
