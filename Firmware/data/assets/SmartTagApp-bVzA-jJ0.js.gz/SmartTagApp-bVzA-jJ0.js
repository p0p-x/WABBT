import{u as t,j as e}from"./index-DJIs-emK.js";import{B as s}from"./common-Cbee4p2Y.js";import"./Button-B0IXh9Bd.js";const o={id:"smarttag",opt:14,name:"Smart Tagger",class:"defensive",color:"primary",desc:`
  Detects smart tags
  such as AirTags and
  Tiles. It will attempt
  to connect and set
  off an audio alert
  on the device.`},p=()=>{const a=t();return e.jsx(s,{app:o,onBack:()=>a("/ble")})};export{p as SmartTagApp,p as default};
