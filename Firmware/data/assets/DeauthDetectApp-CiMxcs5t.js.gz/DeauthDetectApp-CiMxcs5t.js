import{u as o,j as r}from"./index-DUvdTrms.js";import{B as i}from"./common-BEBxH9eT.js";import"./Button-DHX7WF2Q.js";const c={id:"ddetect",opt:6,name:"Deauth Detect",class:"defensive",color:"primary",desc:`
  Detects deauthentiction
  frames that are sent. Useful
  to figure out if your
  network is under attack
  or other maliciousness.
`},f=()=>{const t=o(),e=(s,a)=>{s>0?(stopDetect(),a(-1)):t("/wifi")};return r.jsx(i,{app:c,onBack:e})};export{f as DeauthDetectApp,f as default};
