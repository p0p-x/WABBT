import{u as s,j as e}from"./index-DUvdTrms.js";import{B as o}from"./common-BEBxH9eT.js";import"./Button-DHX7WF2Q.js";const t={id:"fpspam",opt:7,name:"FastPair Spam",class:"offensive",color:"error",desc:`
  Sends Google FastPair BLE
  advertisements that can cause
  popups on some phones.
`},i=()=>{const a=s();return e.jsx(o,{app:t,onBack:()=>a("/ble")})};export{i as FastPairSpamApp,i as default};
